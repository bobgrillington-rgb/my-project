@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Prepare-Recording-Clips.ps1" %*
echo.
pause
