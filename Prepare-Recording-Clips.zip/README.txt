PREPARE EXISTING RECORDINGS FOR UPLOAD - WINDOWS

1. Extract this ZIP into a folder.
2. Double-click Prepare-Recording-Clips.cmd and select your existing videos.
   You can also drag the videos onto the CMD file.
3. Let conversion finish, then upload the generated *_clip_*.mp4 files.

No need to record again or sit watching the conversion. It keeps your voice,
creates four-minute clips below 32 MiB, and leaves the originals unchanged.
The new folders appear beside the originals. Clip names include the source
recording name and sequence number to keep the instructions in order.
Upload the clips in batches if
your chat limits the number of attachments in one message.

Conversion runs locally. It uses up to 1920-pixel-wide video at 12 fps with
1 Mbps video and 32 kbps mono audio, keeping each clip under the transfer cap.
Videos are not uploaded by this utility.

If FFmpeg is not already installed, the first run downloads the Windows build
from https://github.com/BtbN/FFmpeg-Builds into your temporary folder and checks
its published SHA-256 checksum. No administrator install or PATH change is made.
FFmpeg is separate open-source software: https://ffmpeg.org/legal.html
