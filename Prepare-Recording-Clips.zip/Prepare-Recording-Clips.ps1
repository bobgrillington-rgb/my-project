param([Parameter(ValueFromRemainingArguments = $true)][string[]]$VideoFiles)
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

if (-not $VideoFiles -or $VideoFiles.Count -eq 0) {
    Add-Type -AssemblyName System.Windows.Forms
    $picker = New-Object System.Windows.Forms.OpenFileDialog
    $picker.Title = 'Choose your existing recordings (no need to record again)'
    $picker.Filter = 'Video files|*.mp4;*.mkv;*.mov;*.webm|All files|*.*'
    $picker.Multiselect = $true
    if ($picker.ShowDialog() -ne 'OK') { exit 0 }
    $VideoFiles = $picker.FileNames
}

$ffmpegCommand = Get-Command ffmpeg.exe -ErrorAction SilentlyContinue
if ($ffmpegCommand) {
    $ffmpegPath = $ffmpegCommand.Source
} else {
    $toolsFolder = Join-Path $env:TEMP 'BobtonVideoPrep'
    New-Item -ItemType Directory -Force -Path $toolsFolder | Out-Null
    $cached = Get-ChildItem -LiteralPath $toolsFolder -Filter ffmpeg.exe -Recurse | Select-Object -First 1
    if (-not $cached) {
        Write-Host 'Downloading FFmpeg from BtbN/FFmpeg-Builds into a temporary folder...'
        $release = 'https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/'
        $archiveName = 'ffmpeg-master-latest-win64-gpl.zip'
        $archivePath = Join-Path $toolsFolder $archiveName
        $checksums = (Invoke-WebRequest -UseBasicParsing -Uri ($release + 'checksums.sha256')).Content
        if ($checksums -is [byte[]]) { $checksums = [Text.Encoding]::UTF8.GetString($checksums) }
        $pattern = '(?m)^([a-fA-F0-9]{64})\s+\*?ffmpeg-master-latest-win64-gpl\.zip\s*$'
        if ($checksums -notmatch $pattern) { throw 'Could not verify the FFmpeg checksum listing.' }
        $expectedHash = $Matches[1]
        Invoke-WebRequest -UseBasicParsing -Uri ($release + $archiveName) -OutFile $archivePath
        if ((Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash -ne $expectedHash) {
            throw 'FFmpeg download verification failed. Delete the temporary ZIP and retry.'
        }
        Expand-Archive -LiteralPath $archivePath -DestinationPath $toolsFolder -Force
        $cached = Get-ChildItem -LiteralPath $toolsFolder -Filter ffmpeg.exe -Recurse | Select-Object -First 1
    }
    if (-not $cached) { throw 'FFmpeg was not found after extraction.' }
    $ffmpegPath = $cached.FullName
}

$videoIndex = 0
foreach ($videoPath in $VideoFiles) {
    $videoIndex++
    $videoFile = Get-Item -LiteralPath $videoPath
    if ($videoFile.PSIsContainer) { throw 'Select video files, rather than a folder.' }
    $folderName = $videoFile.BaseName + '_upload_parts_' + (Get-Date -Format 'yyyyMMdd_HHmmss')
    $outputFolder = Join-Path $videoFile.DirectoryName $folderName
    New-Item -ItemType Directory -Path $outputFolder | Out-Null
    $outputName = ('{0:D2}_{1}_clip_%03d.mp4' -f $videoIndex, $videoFile.BaseName.Replace('%', '%%'))
    $outputPattern = Join-Path $outputFolder $outputName
    Write-Host ('Preparing smaller clips from: ' + $videoFile.Name)
    $ffmpegArguments = @('-hide_banner', '-nostdin', '-n', '-i', $videoFile.FullName,
        '-map', '0:v:0', '-map', '0:a:0?',
        '-vf', "scale=w='min(1920,iw)':h=-2,fps=12", '-c:v', 'libx264', '-preset', 'veryfast',
        '-b:v', '1000k', '-maxrate', '1000k', '-bufsize', '1000k', '-pix_fmt', 'yuv420p',
        '-g', '48', '-sc_threshold', '0', '-c:a', 'aac', '-ac', '1', '-ar', '24000', '-b:a', '32k',
        '-f', 'segment', '-segment_time', '240', '-reset_timestamps', '1',
        '-segment_format', 'mp4', '-segment_format_options', 'movflags=+faststart', $outputPattern)
    & $ffmpegPath @ffmpegArguments
    if ($LASTEXITCODE -ne 0) { throw 'Video conversion stopped. Your original recording is unchanged.' }
    $clips = @(Get-ChildItem -LiteralPath $outputFolder -Filter '*.mp4')
    if ($clips.Count -eq 0) { throw 'No output clips were produced.' }
    if (@($clips | Where-Object { $_.Length -ge 32MB }).Count -gt 0) {
        throw ('A clip is still too large. The output is in ' + $outputFolder)
    }
    Write-Host ('Ready: ' + $clips.Count + ' clips below 32 MB in ' + $outputFolder) -ForegroundColor Green
}
Write-Host 'Upload the generated *_clip_*.mp4 files to the chat. Original recordings are unchanged.'
